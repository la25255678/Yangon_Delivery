									   <?php include ('connect.php');
                                       error_reporting(1);
                            if (isset($_POST['go'])) {

                                $name = $_POST['name'];
                                $price = $_POST['price'];
                                $category = $_POST['category'];

                                //image
                                $img=$_FILES['img']['name'];
                                {mkdir("image/$i");
//
                                move_uploaded_file($_FILES["img"]["tmp_name"], "image/$i". $_FILES["img"]["name"]);
                                }


                                mysql_query("insert into food (name,price,category,img)
                            	values ('$name','$price','$category','$img')
                                ") or die(mysql_error());
                            }
                            ?>
